import React from 'react'

const AuthLayout = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="">{children}</div>
  )
}

export default AuthLayout
